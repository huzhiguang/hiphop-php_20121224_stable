
#include "mongo.h"

mongo *mongo_connection_create(int timeout, mongo_host_port *host_port, char **error_message ) ;

void mongo_connection_destroy(mongo_con_manager *manager, mongo *conn );

