#include "connections.h"

#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/time.h>


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#define INT_32 4
#define FLAGS 0


static int mongo_util_connect__sockaddr(struct sockaddr *sa, int family, char *host, int port, char **errmsg)
{
#ifndef WIN32
	if (family == AF_UNIX) {
		struct sockaddr_un* su = (struct sockaddr_un*)(sa);
		su->sun_family = AF_UNIX;
		strncpy(su->sun_path, host, sizeof(su->sun_path));
	} else {
#endif
		struct hostent *hostinfo;
		struct sockaddr_in* si = (struct sockaddr_in*)(sa);

		si->sin_family = AF_INET;
		si->sin_port = htons(port);
		hostinfo = (struct hostent*)gethostbyname(host);

		if (hostinfo == NULL) {
			*errmsg = malloc(256);
			snprintf(*errmsg, 256, "Couldn't get host info for %s", host);
			return 0;
		}

#ifndef WIN32
		//si->sin_addr = *((struct in_addr*)hostinfo->h_addr); // danger: coredump
		
		if ( hostinfo && hostinfo->h_addr ) {
			si->sin_addr = *((struct in_addr*)hostinfo->h_addr);
		}
	
	}
#else
	si->sin_addr.s_addr = ((struct in_addr*)(hostinfo->h_addr))->s_addr;
#endif

	return 1;
}

/* This function does the actual connecting */
int mongo_connection_connect(char *host, int port, int timeout, char **error_message)
{
	struct sockaddr*   sa;
	struct sockaddr_in si;
	socklen_t          sn;
	int                family;
	struct timeval     tval;
	int                connected;
	int                status = -1 ;
	int                tmp_socket;

	struct sockaddr_un su;
	uint               size;
	int                yes = 1;

	*error_message = NULL;



	/* domain socket */
	if (port == 0) {
		family = AF_UNIX;
		sa = (struct sockaddr*)(&su);
		sn = sizeof(su);
	} else {
		family = AF_INET;
		sa = (struct sockaddr*)(&si);
		sn = sizeof(si);
	}

	/* create socket */
	if ((tmp_socket = socket(family, SOCK_STREAM, 0)) == -1) {
		*error_message = strdup(strerror(errno));
		return -1;
	}

	/* TODO: Move this to within the loop & use real timeout setting */
	/* connection timeout: set in ms (current default 1 sec) */
	tval.tv_sec = timeout <= 0 ? 1 : timeout / 1000;
	tval.tv_usec = timeout <= 0 ? 0 : (timeout % 1000) * 1000;

	/* get addresses */
	if (mongo_util_connect__sockaddr(sa, family, host, port, error_message) == 0) {
		goto error;
	}

	setsockopt(tmp_socket, SOL_SOCKET, SO_KEEPALIVE, &yes, INT_32);
	setsockopt(tmp_socket, IPPROTO_TCP, TCP_NODELAY, &yes, INT_32);
	setsockopt(tmp_socket, SOL_SOCKET, SO_RCVTIMEO, &tval, sizeof( tval ) ) ;
	setsockopt(tmp_socket, SOL_SOCKET, SO_SNDTIMEO, &tval, sizeof( tval ) ) ;

	fcntl(tmp_socket, F_SETFL, FLAGS|O_NONBLOCK);

	/* connect */
	status = connect(tmp_socket, sa, sn);
	if (status < 0) {
		if (errno != EINPROGRESS) {
			*error_message = strdup(strerror(errno));
			goto error;
		}

		while (1) {
			fd_set rset, wset, eset;

			FD_ZERO(&rset);
			FD_SET(tmp_socket, &rset);
			FD_ZERO(&wset);
			FD_SET(tmp_socket, &wset);
			FD_ZERO(&eset);
			FD_SET(tmp_socket, &eset);

			if (select(tmp_socket+1, &rset, &wset, &eset, &tval) == 0) {
				*error_message = malloc(256);
				snprintf(*error_message, 256, "Timed out after %d ms", timeout);
				goto error;
			}

			/* if our descriptor has an error */
			if (FD_ISSET(tmp_socket, &eset)) {
				*error_message = strdup(strerror(errno));
				goto error;
			}

			/* if our descriptor is ready break out */
			if (FD_ISSET(tmp_socket, &wset) || FD_ISSET(tmp_socket, &rset)) {
				int error = 0 ;
				socklen_t len = sizeof( int ) ;
				if( getsockopt( tmp_socket,   SOL_SOCKET,   SO_ERROR,   &error,   &len) < 0 ) {
					status = -1 ;
					goto error ;
				}
				if (error   ==   ETIMEDOUT) {
					status = -2 ;
					goto error ;
				}
				if ( error == ECONNREFUSED ) {
					status = -3 ;
					goto error ;
				}
				break;
			}
		}

		size = sn;

		connected = getpeername(tmp_socket, sa, &size);
		if (connected == -1) {
			*error_message = strdup(strerror(errno));
			goto error;
		}
	}

	/* reset flags */
	fcntl(tmp_socket, F_SETFL, FLAGS);
	return tmp_socket;

error:
	shutdown((tmp_socket), 2);
	close(tmp_socket);
	return status ;
}


mongo *mongo_connection_create(int timeout,  mongo_host_port *host_port, char **error_message ) {
	mongo *tmp ;
	
	/*  Init struct */
	tmp = (mongo*)malloc(sizeof(mongo)) ;
	memset( tmp, 0, sizeof(mongo) ) ;
	tmp->last_reqid = rand() ;

	/* Connect */
	tmp->sock = mongo_connection_connect( host_port->host, host_port->port, timeout, error_message) ;
	if ( tmp->sock < 0) {
		// free(tmp) ;
		switch ( tmp->sock ) {
			case -1: tmp->err = MONGO_CONN_FAIL ; break ;
			case -2: tmp->err = MONGO_CONN_TIMEOUT; break ;
			case -3: tmp->err = MONGO_NO_LISTEN_ADDR; break ;
		}
		return tmp ;
	}
	struct timeval cur_time ;
	gettimeofday( &cur_time, NULL );
	tmp->last_ping = cur_time.tv_sec ;
	tmp->connected = 1 ;
	tmp->err = MONGO_CONN_SUCCESS ;
	return tmp ;
}

void mongo_connection_destroy(mongo_con_manager *manager, mongo *con)
{
	pthread_t current_tid,  connection_tid ;
	current_tid = pthread_self() ;
	connection_tid = con->tid ;

	/* Only close the connection if it matches the current TID */
	if ( !pthread_equal( connection_tid, current_tid ) ) {
		//mongo_manager_log(manager, MLOG_CON, MLOG_INFO, "mongo_connection_destroy: The process pid (%d) for %s doesn't match the connection pid (%d).", current_pid, con->hash, connection_pid);
	} else {
		// mongo_manager_log(manager, MLOG_CON, MLOG_FINE, "mongo_connection_destroy: Closing socket for %s.", con->hash);

		shutdown(con->sock, SHUT_RDWR);
		close(con->sock);
		free(con);
		/*
		int i;
		for (i = 0; i < con->tag_count; i++) {
			free(con->tags[i]);
		}
		if (con->cleanup_list) {
			mongo_connection_deregister_callback *ptr = con->cleanup_list;
			mongo_connection_deregister_callback *prev;
			do {
				if (ptr->callback_data) {
					ptr->mongo_cleanup_cb(ptr->callback_data);
				}

				if (!ptr->next) {
					free(ptr);
					ptr = NULL;
					break;
				}
				prev = ptr;
				ptr = ptr->next;
				free(prev);
				prev = NULL;
			} while(1);
			con->cleanup_list = NULL;
		}
		free(con->tags);
		free(con->hash);
		*/
	}
}
