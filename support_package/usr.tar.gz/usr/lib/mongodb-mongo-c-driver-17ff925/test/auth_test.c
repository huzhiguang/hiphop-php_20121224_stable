#include "test.h"
#include "mongo.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static const char *db = "test";

int main() {


    INIT_SOCKETS_FOR_WINDOWS;

	
	mongo_con_manager *manager = mongo_manager_init() ;

	mongo *conn_tmp = mongo_client( manager, NULL, TEST_SERVER, 8012 ) ;
	
   int status =  mongo_cmd_authenticate( conn_tmp, db, "lvbu", "123" ) ;
   printf( "status = %d\n", status ) ;
	/*
    if ( mongo_client( conn , TEST_SERVER, 8088) ) {
        printf( "failed to connect\n" );
        exit( 1 );
    }
	*/

	mongo_cursor cursor[1] ;
	mongo_cursor_init( cursor, conn_tmp, "test.things") ;

	while ( MONGO_OK ==  mongo_cursor_next( cursor )) {
		bson_print( &cursor->current) ;
	}


	printf("xxxxx print primary connections.....\n") ;


    //mongo_cmd_drop_db( conn, db );


 //   mongo_cmd_add_user( conn, db, "user", "password" );
  //  ASSERT( mongo_cmd_authenticate( conn, db, "user", "password" ) == MONGO_OK );

   //  mongo_cmd_drop_db( conn, db );
    //mongo_destroy( conn );
    return 0;
}
