#include <stdio.h>
#include "mongo.h"

int main() {
	


//char *server_spec = "mongodb://user1:123@192.168.12.62:8089,192.168.12.62:8088,192.168.12.62:8087/test" ;
//char *server_spec = "mongodb://192.168.12.62:8087/test" ;


//char *server_spec = "mongodb://192.168.12.34:27018/club" ;
char *server_spec = "mongodb://192.168.12.34:27017/club" ;
	

	mongo_con_manager *manager = mongo_manager_init() ;



	//mongo_replica_set *servers = (mongo_replica_set*)malloc(sizeof(mongo_replica_set)) ;
	mongo_replica_set *servers = mongo_replica_set_init() ;
	//mongo_replica_set_op_timeout( servers, 2000 ) ;

	printf( " parse server spec : servers->count = %d\n", servers->count ) ;
	char *error_message ;
	int status = mongo_parse_server_spec( manager, servers, server_spec, (char **)&error_message) ;
	if ( MONGO_ERROR == status ) {
		return -1 ;
	}	
	printf( " parse server spec result: servers->count = %d\n", servers->count ) ;
	mongo_replica_set_print( &servers->seeds) ;

/*
	mongo_replica_set_init( conn, "rs0") ;
	mongo_replica_set_add_seed( conn, "192.168.12.62", 8087) ;
	mongo_replica_set_add_seed( conn, "192.168.12.62", 8088) ;
	mongo_replica_set_add_seed( conn, "192.168.12.62", 8089) ;
*/	
	


	
	//mongo_host_port *node = conn->replica_set->seeds ;
//	mongo_host_port *node = servers->seeds ;
//	printf(" node = 0x%p\n", (void*)node) ;
//		if ( node ) {
//		while ( node->next ) {
//			printf( " host = %s, port = %d \n", node->host, node->port ) ;
//			node =  node->next ;
//		}
//			printf( " host = %s, port = %d \n", node->host, node->port ) ;
//		printf("\n\n") ;
//	} else {
//		return -1 ;
//	}



	/*
	mongo conn[1] ;
	//mongo* conn_tmp = mongo_client( manager, conn, "192.168.12.62", 8088) ; 
	mongo* conn_tmp = mongo_client( NULL, conn, "192.168.12.63", 27017) ; 
	//mongo* conn_tmp = mongo_client( NULL, conn, "192.168.12.62", 8087) ; 
	 //mongo* conn_tmp = mongo_client( NULL, conn, "192.168.12.62", 8088) ; 
	//mongo* conn_tmp = mongo_client( NULL, conn, "192.168.12.62", 8089) ; 
	*/






 	int isPrimary =  mongo_replica_set_find_primary( manager, servers) ;
	printf( " isPrimary = %d\n", isPrimary ) ;
	if ( MONGO_OK == isPrimary) {
		mongo_manager_connection_print( manager ) ;


	} else {
		return -1 ;
	}
	mongo* conn_tmp  = mongo_replica_set_client( manager,  servers ) ;
	printf(" conn_tmp = 0x%p, conn_tmp->err = %d\n", (void*)conn_tmp, conn_tmp->err) ;
	if ( NULL == conn_tmp) {
		return -1 ;
	}
	conn_tmp->err ;


	/** authenticate 
	 */
	char *db = "test" ;
   status =  mongo_cmd_authenticate( conn_tmp, db, "user1", "123" ) ;
   printf( " ********************************* authenticate : status = %d\n", status ) ;


	mongo_cursor cursor[1] ;
//	mongo_cursor_init( cursor, conn_tmp, "test.things") ;
	mongo_cursor_init( cursor, conn_tmp, "club.comment") ;


	while ( MONGO_OK ==  mongo_cursor_next( cursor )) {
		bson_print( &cursor->current) ;
	}


	printf("xxxxx print primary connections.....\n") ;

	printf("xxxxx print manager connections.....\n") ;

	
	/*
	mongo_con_manager_item *ptr = manager->connections ;
	if ( ptr ) {
		do {
			if (!ptr->next) {
				break;
			}
			printf( "ptr->connection  = 0x%x, ptr->hash = %s\n\n", ptr->connection, ptr->hash) ;
			ptr = ptr->next;
		} while (1);
			printf( "ptr->connection  = 0x%x, ptr->hash = %s\n\n", ptr->connection, ptr->hash) ;
	} 
	*/
	mongo_cursor_destroy( cursor ) ;
	return 0 ; 
	
}
