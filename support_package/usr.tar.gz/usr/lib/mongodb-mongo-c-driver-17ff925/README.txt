
1) make
2) copy all .so fle to hphp library
	e.g. cp *.so $CMAKE_PREFIX_PATH
3) test:
	test php file: test/test_mongodb_frame.php
	test c file: test/test_replica_set.c
		e.g. gcc -g -Wall -D MONGO_HAVE_STDINT -I ../src/ -o test_replica_set.bin test_replica_set.c  -L ../ -l mongoc
